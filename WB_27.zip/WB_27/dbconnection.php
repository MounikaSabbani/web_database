<?php
$server = "localhost";
$username = "kandem";
$password = "ursuline canned hamburg";
$database = "kandem_db";
$file_location = "/~kandem/WB_26/";


// Create connection
$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
	
}

?>